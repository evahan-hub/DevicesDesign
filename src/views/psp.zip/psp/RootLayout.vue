<template>
  <div class="root-layout">
    <SideNavigation />
    <div class="main-area">
      <TopBar>
        <nav v-if="breadcrumbs.length" class="breadcrumb">
          <span class="breadcrumb__item" :class="{ 'breadcrumb__item--active': breadcrumbs.length === 1 }">{{ breadcrumbs[0].label }}</span>
          <template v-if="breadcrumbs.length >= 2">
            <svg class="breadcrumb__icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none">
              <path fill="var(--b-color-label-secondary)" d="M5.43924 10.9999L8.43924 7.99989L5.43924 4.99989L6.4999 3.93923L10.5606 7.99989L6.4999 12.0605L5.43924 10.9999Z" />
            </svg>
            <span class="breadcrumb__item breadcrumb__item--active">{{ breadcrumbs[1].label }}</span>
          </template>
        </nav>
      </TopBar>
      <div class="content-area">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router/composables';
import SideNavigation from '../../components/SideNavigation.vue';
import TopBar from '../../components/TopBar.vue';

const SECTION_LABELS: Record<string, string> = {
  'in-person-payments': 'In-person payments',
  'transactions': 'Transactions',
  'accounts': 'Accounts & balances',
  'revenue-risk': 'Revenue & risk',
  'finance': 'Finance',
  'insights': 'Insights',
  'pay-by-link': 'Pay by link',
  'giving': 'Giving',
  'developers': 'Developers',
  'partner': 'Partner',
  'reports': 'Reports',
};

const PAGE_LABELS: Record<string, string> = {
  'tap-to-pay': 'Tap to pay & card reader',
  'orders-returns': 'Orders & returns',
  'stores': 'Stores',
  'terminals': 'Terminals',
  'terminal-settings': 'Terminal settings',
  'android': 'Android',
  'payment-devices': 'Payment devices',
  'terminal-software': 'Terminal software',
  'themes': 'Themes',
  'payments': 'Payments',
  'offers': 'Offers',
  'payouts': 'Payouts',
  'account-holders': 'Account holders',
  'score': 'Score',
  'uplift-overview': 'Uplift overview',
  'recommendations': 'Recommendations',
  'case-management': 'Case management',
  'disputes': 'Disputes',
  'dynamic-3d-secure': 'Dynamic 3D Secure',
  'experiments': 'Experiments',
  'risk-fields': 'Risk fields',
  'risk-lists': 'Risk lists',
  'risk-profiles': 'Risk profiles',
  'risk-profile-details': 'Risk profile details',
  'settings': 'Settings',
  'balances-overview': 'Balances overview',
  'company-balances-overview': 'Company balances overview',
  'mpl': 'MPL',
  'invoices': 'Invoices',
  'sales-to-payouts': 'Sales to payouts',
  'payout-accounts': 'Payout accounts',
  'reporting-manager': 'Reporting manager',
  'integration-guide': 'Integration guide',
  'dashboard': 'Dashboard',
  'api-credentials': 'API credentials',
  'webhooks': 'Webhooks',
  'payment-links': 'Payment links',
  'campaigns': 'Campaigns',
  'overview': 'Overview',
  'referrals': 'Referrals',
  'merchant-access': 'Merchant access',
  'checkout': 'Checkout',
  'payment-lifecycle': 'Payment lifecycle',
  'risk-dispute-management': 'Risk & dispute management',
  'home': 'Home',
  'performance': 'Performance',
};

const route = useRoute();

const breadcrumbs = computed(() => {
  const path = route?.path || '/';
  const segments = path.split('/').filter(Boolean);
  if (segments.length === 0) return [{ label: 'Home' }];
  if (segments.length === 1) {
    const label = SECTION_LABELS[segments[0]] || PAGE_LABELS[segments[0]] || segments[0];
    return [{ label }];
  }
  const parentLabel = SECTION_LABELS[segments[0]] || segments[0];
  const pageLabel = PAGE_LABELS[segments[segments.length - 1]] || segments[segments.length - 1];
  return [{ label: parentLabel }, { label: pageLabel }];
});
</script>

<style scoped>
.root-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.main-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  overflow: hidden;
}

.content-area {
  flex: 1;
  overflow-y: auto;
  background-color: var(--b-color-background-primary);
  padding-top: var(--b-spacer-080);
  padding-left: var(--b-spacer-090);
}

.breadcrumb {
  display: flex;
  align-items: center;
  gap: 0;
}

.breadcrumb__item {
  font-family: var(--b-text-caption-font-family);
  font-size: var(--b-text-caption-font-size);
  line-height: var(--b-text-caption-line-height);
  font-weight: 400;
  color: var(--b-color-label-secondary);
  white-space: nowrap;
}

.breadcrumb__item--active {
  font-weight: 600;
  color: var(--b-color-label-primary);
}

.breadcrumb__icon {
  flex-shrink: 0;
}
</style>
