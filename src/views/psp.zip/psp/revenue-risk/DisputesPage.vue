<template>
  <div class="page page--locked page--data-grid-template">
    <bento-data-grid-template 
      class="content-section--flex" 
      :header="headerConfig" 
      :tabs="tabsConfig" 
      sticky-tabs
    >
      <template v-for="index in tabsConfig.tabs.length" v-slot:[getTabSlotName(index-1)]>
        <bento-data-grid
          :key="index"
          :columns="columns"
          :data="getTabData(index-1)"
          :filters="filtersConfig"
          :filter-values="filterValues"
          :filter-search-term="searchTerm"
          selectable
          column-panel
          allow-column-drag-and-drop
          fit-content
          :selection="selection"
          :pagination="pagination"
          @update:selection="selection = $event"
          @update:columns="columns = $event"
          @update:pagination="pagination = $event"
          @update:filter-values="filterValues = $event"
          @update:filter-search-term="searchTerm = $event"
        >
          <template #item-assignee>
            <bento-button variant="secondary" size="small" :condensed="true" class="no-wrap-btn">
              Assign
            </bento-button>
          </template>

          <template #item-pspReference="{ item }">
            <bento-link is-not-routing to="#" :title="item.pspReference">
              {{ item.pspReference }}
            </bento-link>
          </template>
        </bento-data-grid>
      </template>
    </bento-data-grid-template>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue';
import {
  BentoButton, BentoDataGrid, BentoDataGridTemplate, BentoLink,
  BentoColumnOverflow, BentoFilterItemType,
} from '@adyen/bento-vue2';
import type { BentoColumn, BentoDatagridSelection, BentoFilterBarModel, BentoFilterValues } from '@adyen/bento-vue2';

const headerConfig = { title: 'Disputes' };
const tabsConfig = { tabs: [{ title: 'Chargebacks' }, { title: 'Requests for information' }, { title: 'Notification of fraud' }] };

const selection = ref<BentoDatagridSelection>([]);
const pagination = ref({ page: 1, size: 20, totalCount: 16, pageSizes: [10, 20, 50, 100] });
const searchTerm = ref('');
const filterValues = ref<BentoFilterValues>([]);

const filtersConfig: BentoFilterBarModel = [
  { field: 'reason', label: 'Dispute Reason', value: null, type: BentoFilterItemType.INPUT },
  { field: 'lastEvent', label: 'Last Event', value: null, options: { listboxItems: [{ value: 'Chargeback', label: 'Chargeback' }, { value: 'DisputeOpenedWithChargeback', label: 'DisputeOpenedWithChargeback' }, { value: 'DisputeExpired', label: 'DisputeExpired' }] }, type: BentoFilterItemType.SELECT },
];

const columns = ref<BentoColumn[]>([
  { field: 'assignee', label: 'Assignee', width: 120 },
  { field: 'pspReference', label: 'Dispute PSP reference', minWidth: 200, overflow: BentoColumnOverflow.ELLIPSIS },
  { field: 'reason', label: 'Dispute reason', minWidth: 260, overflow: BentoColumnOverflow.ELLIPSIS },
  { field: 'lastEvent', label: 'Last event', minWidth: 260, overflow: BentoColumnOverflow.ELLIPSIS },
  { field: 'date', label: 'Dispute date', minWidth: 180, overflow: BentoColumnOverflow.ELLIPSIS },
]);

const disputes = ref([
  { id: '1', assignee: null, pspReference: 'KDN8FPRT3BGT9Y7C', reason: 'R01 Insufficient Funds', lastEvent: 'Chargeback', date: 'Feb 14, 2025, 08:15' },
  { id: '2', assignee: null, pspReference: 'VXZ2LMNQ5JHW6R4P', reason: 'AC01:IncorrectAccountNumber', lastEvent: 'DisputeOpenedWithChargeback', date: 'Mar 22, 2025, 12:30' },
  { id: '3', assignee: null, pspReference: 'S4G7CKB9Z1DFM3V', reason: 'No Instruction', lastEvent: 'Chargeback', date: 'Apr 01, 2025, 09:00' },
  { id: '4', assignee: null, pspReference: 'T8YHJN5R2WEXQ6A9', reason: 'Improper Effective Entry Date', lastEvent: 'Chargeback', date: 'May 30, 2025, 17:45' },
  { id: '5', assignee: null, pspReference: 'P6M3C7V1L9KDF2Z8', reason: 'Account not found', lastEvent: 'DisputeExpired', date: 'Jun 06, 2025, 21:05' },
  { id: '6', assignee: null, pspReference: 'B5N4W7S8G9R2T1Q', reason: 'Not Sufficient Funds (Debit Only)', lastEvent: 'Chargeback', date: 'Jul 04, 2025, 10:10' },
  { id: '7', assignee: null, pspReference: 'F3H2J6K1L5P9M7N8', reason: 'MS03:NotSpecifiedReasonAgentGenerated', lastEvent: 'DisputeOpenedWithChargeback', date: 'Aug 19, 2025, 14:22' },
  { id: '8', assignee: null, pspReference: 'ZXC7VBNM4LKJHG2F', reason: 'R01 Insufficient Funds', lastEvent: 'Chargeback', date: 'Sep 05, 2025, 11:11' },
  { id: '9', assignee: null, pspReference: 'QWERT9YUI1OPASDF', reason: 'No Instruction', lastEvent: 'Chargeback', date: 'Oct 31, 2025, 23:59' },
  { id: '10', assignee: null, pspReference: 'G5HJK3L4M2NBVCX', reason: 'Account not found', lastEvent: 'DisputeExpired', date: 'Nov 27, 2025, 06:45' },
  { id: '11', assignee: null, pspReference: 'R4T6Y8U1I3O5P7A9', reason: 'AC01:IncorrectAccountNumber', lastEvent: 'Chargeback', date: 'Dec 25, 2025, 07:00' },
  { id: '12', assignee: null, pspReference: 'S2D4F6G8H1J3K5L7', reason: 'Not Sufficient Funds (Debit Only)', lastEvent: 'DisputeOpenedWithChargeback', date: 'Jan 15, 2025, 18:00' },
  { id: '13', assignee: null, pspReference: 'X1C3V5B7N9M2L4K6', reason: 'MS03:NotSpecifiedReasonAgentGenerated', lastEvent: 'Chargeback', date: 'Jul 20, 2025, 03:45' },
  { id: '14', assignee: null, pspReference: 'A8S7D6F5G4H3J2K1', reason: 'Improper Effective Entry Date', lastEvent: 'DisputeExpired', date: 'Sep 22, 2025, 16:55' },
  { id: '15', assignee: null, pspReference: 'POIU9YTRE6WQAS2D', reason: 'R01 Insufficient Funds', lastEvent: 'DisputeOpenedWithChargeback', date: 'Nov 11, 2025, 13:13' },
  { id: '16', assignee: null, pspReference: 'MNB4VCX5ZLKJHG3F', reason: 'No Instruction', lastEvent: 'Chargeback', date: 'Dec 31, 2025, 23:00' },
]);

const filteredAndSortedData = computed(() =>
  disputes.value.filter(item => {
    const matchesFilters = filterValues.value.length > 0
      ? filterValues.value.every((filter: any) => {
          if (!filter.value) return true;
          return String(item[filter.field as keyof typeof item]).toLowerCase().includes(String(filter.value).toLowerCase());
        })
      : true;
    const matchesSearch = searchTerm.value
      ? String(item.pspReference).toLowerCase().includes(searchTerm.value.toLowerCase())
      : true;
    return matchesFilters && matchesSearch;
  })
);

function getTabSlotName(index: number): string { return `tab-${index + 1}`; }

function getTabData(index: number): any[] {
  const data = filteredAndSortedData.value;
  if (index === 0) return data.filter(d => d.lastEvent === 'Chargeback');
  if (index === 1) return data.filter(d => d.lastEvent === 'DisputeOpenedWithChargeback');
  if (index === 2) return data.filter(d => d.lastEvent === 'DisputeExpired');
  return data;
}
</script>

<style scoped>
.no-wrap-btn {
  white-space: nowrap;
}
</style>